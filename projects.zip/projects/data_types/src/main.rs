fn main() {
    //integers
        let a: i32 = 98_222; // decimal 
        let b: i32 = 0xff; // hex
        let c: i32 = 0o77; // octal
        let d: i32 = 0b1111_0000; //Binary
        let e: u8 = b'A'; // Byte (u8 only)

        let f: u8 = 255; // integer overflow
    //floating-point number
        let f: f64 = 2.0;
        let g: f32 = 3.0;

    // addition 
        let sum: i32 = 5 + 10;
    //subtraction
        let difference: i32 = 5 - 10;
    //multiplication
        let product: i32 = 4 * 30;
    //division
        let quotient: f64 = 55.5 / 55.5;
    //remainder
        let remainder: i32 = 53 % 5;
    //boolean
        let t: bool = true;

        let f: bool = false;

    //character
        let c: char = 'z';
        let z: char = 'Z';
        let emoji: char = 'ᗢ';
}
