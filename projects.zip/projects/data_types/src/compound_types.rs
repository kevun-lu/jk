fn main() {
    // compound types
    // Tuples
    let tup: (i32, f64, u8, &str) = (500, 6.9, 1 "I will learn Rust");

    let (x,y,z,a) = tup;

    println!("The value of a is: {y}")

    let five_hundred = x.0;

    let six_point_nine = x.1;

    let one = x.3;

    let i_will_learn_rust = x.4;

    //array
    let a = [1, 2, 4, 6]
    
    let b: [i32, 4] = [1,2,3,4];

    let c: [1; 10]

    let first = a[0];
    let second = b[0];
}

fn array() {
    let a = [1, 2, 3, 4, 5];

    println!("Please enter an array index.");

    let mut index = String::new();

    io::stdin()
        .read_line(&mut index)
        .expect("Failed to read line");

    let index: usize = index
        .trim()
        .parse()
        .expect("Index entered was not a number");

    let element = a[index];

    println!("The value of the element at index {index} is: {element}");
}