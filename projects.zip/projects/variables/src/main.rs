fn main() {
    let x: i32 = 5;
    println!("The value of x is: {}", x);
    let x: &str = "six";
    println!("The value of x is: {}", x);
}



